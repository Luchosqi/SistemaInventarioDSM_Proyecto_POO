package org.example;

public class Main {

    public static void main(String[] args) {
        EnviarCorreo correo = new EnviarCorreo();

        // Definir los parámetros para el correo
        String destinatario = "l.jaramillo02@ufromail.cl";
        String producto = "Producto de ejemplo";
        String costo = "$100";
        String lugarRetiro = "NOTRO";

        // Enviar el correo
        correo.enviarCorreo(destinatario, producto, costo, lugarRetiro);
    }
}
