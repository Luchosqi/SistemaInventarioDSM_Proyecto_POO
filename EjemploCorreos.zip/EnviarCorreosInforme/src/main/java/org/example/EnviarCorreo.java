package org.example;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
public class EnviarCorreo {
    private String servidorSMTP = "smtp.gmail.com";
    private final String usuario = "fronteracompra@gmail.com";
    private final String contrasena = "zzqu zyym uiya kwhv";
    public void enviarCorreo(String destinatario, String producto, String costo, String lugarRetiro) {
        Properties propiedades = new Properties();
        propiedades.put("mail.smtp.host", servidorSMTP);
        propiedades.put("mail.smtp.port", "587");
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.starttls.enable", "true");
        Session sesion = Session.getInstance(propiedades, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(usuario, contrasena);
            }
        });
        String cuerpo = "Estimado/a " + destinatario + "\n\n"
                + "¡Gracias por realizar tu compra con nosotros!\n"
                + "Detalles de la Compra:\n"
                + "- Producto: " + producto + "\n"
                + "- Costo Total: " + costo + "\n"
                + "Tu pedido esta disponible para retiro en el Casino " + lugarRetiro
                + ". Por favor, lleva una copia de este correo.\n"
                + "Atentamente\n"
                + "El equipo de CompraFrontera";
        try {
            MimeMessage mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress(usuario));
            mensaje.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            mensaje.setSubject("¡Gracias por tu compra en CompraFrontera!");
            mensaje.setText(cuerpo);

            // Envío del correo
            Transport.send(mensaje);
            System.out.println("Correo enviado correctamente.");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}

